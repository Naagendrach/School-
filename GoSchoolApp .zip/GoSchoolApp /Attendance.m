//
//  Attendance.m
//  SchoolApp
//
//  Created by Admin on 04/08/2017.
//  Copyright © 2017 Admin. All rights reserved.
//

#import "Attendance.h"
#import "GoSchool.h"
@interface Attendance ()
{
    WSCalendarView *calendarView;
    WSCalendarView *calendarViewEvent;
    NSMutableArray *eventArray;
}
@property (weak, nonatomic) IBOutlet UIBarButtonItem *backBarBttn;

@end

@implementation Attendance

- (void)viewDidLoad {
    
    
    
    self.profileView.layer.cornerRadius =6; // this value vary as per your desire
    self.profileView.clipsToBounds = YES;
    
    self.containerView.layer.cornerRadius =6; // this value vary as per your desire
    self.containerView.clipsToBounds = YES;
    
    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"1.jpg"]];
    
    [super viewDidLoad];
    calendarView = [[[NSBundle mainBundle] loadNibNamed:@"WSCalendarView" owner:self options:nil] firstObject];
    calendarView.dayColor=[UIColor blackColor];
    calendarView.weekDayNameColor=[UIColor purpleColor];
    calendarView.barDateColor=[UIColor purpleColor];
    calendarView.todayBackgroundColor=[UIColor blackColor];
    calendarView.tappedDayBackgroundColor=[UIColor blackColor];
    calendarView.calendarStyle = WSCalendarStyleDialog;
    calendarView.isShowEvent=false;
    [calendarView setupAppearance];
    [self.view addSubview:calendarView];
    calendarView.delegate=self;
    
    
    calendarViewEvent = [[[NSBundle mainBundle] loadNibNamed:@"WSCalendarView" owner:self options:nil] firstObject];
    calendarViewEvent.calendarStyle = WSCalendarStyleView;
    calendarViewEvent.isShowEvent=true;
    calendarViewEvent.tappedDayBackgroundColor=[UIColor blackColor];
    calendarViewEvent.frame = CGRectMake(0, 0, self.containerView.frame.size.width, self.containerView.frame.size.height);
    [calendarViewEvent setupAppearance];
    calendarViewEvent.delegate=self;
    [self.containerView addSubview:calendarViewEvent];
    
    
    eventArray=[[NSMutableArray alloc] init];
    NSDate *lastDate;
    NSDateComponents *dateComponent=[[NSDateComponents alloc] init];
    for (int i=0; i<10; i++) {
        
        if (!lastDate) {
            lastDate=[NSDate date];
        }
        else{
            [dateComponent setDay:1];
        }
        NSDate *datein = [[NSCalendar currentCalendar] dateByAddingComponents:dateComponent toDate:lastDate options:0];
        lastDate=datein;
        [eventArray addObject:datein];
    }
    [calendarViewEvent reloadCalendar];
    
    NSLog(@"%@",[eventArray description]);
    // Do any additional setup after loading the view.
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    [calendarView ActiveCalendar:textField];
    return YES;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    
}

#pragma mark WSCalendarViewDelegate

-(NSArray *)setupEventForDate{
    return eventArray;
}

-(void)didTapLabel:(WSLabel *)lblView withDate:(NSDate *)selectedDate
{
    
}

-(void)deactiveWSCalendarWithDate:(NSDate *)selectedDate{
    NSDateFormatter *monthFormatter=[[NSDateFormatter alloc] init];
    [monthFormatter setDateFormat:@"dd MMMM yyyy"];
    NSString *str=[monthFormatter stringFromDate:selectedDate];
    //self.txtCalender.text = str;
}
//

- (IBAction)hideKeyboard:(id)sender {
    
    [self.view endEditing:YES];
}

- (IBAction)backBarbttn:(id)sender
{
    
    
    GoSchool*go=[self.storyboard instantiateViewControllerWithIdentifier:@"School"];
    
    //[self.navigationController pushViewController:go animated:YES];
    [self presentViewController:go animated:YES completion:^{
        
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
