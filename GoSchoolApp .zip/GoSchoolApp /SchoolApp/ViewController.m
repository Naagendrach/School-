//
//  ViewController.m
//  SchoolApp
//
//  Created by Admin on 04/08/2017.
//  Copyright © 2017 Admin. All rights reserved.
//

#import "ViewController.h"
#import "GoSchool.h"
#import <QuartzCore/QuartzCore.h>


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"1.jpg"]];
    
    self.loginBttn.layer.cornerRadius = 10; // this value vary as per your desire
    self.loginBttn.clipsToBounds = YES;
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)onLoginBttnTapped:(id)sender {


//    if(self.usernameTxtField.text.length==0||self.passwordTxtField.text.length==0)
//    {
//        
//        UIAlertController * alert = [UIAlertController
//                                     alertControllerWithTitle:@"Alert"
//                                     message:@"Please Fill Username and Password"
//                                     preferredStyle:UIAlertControllerStyleAlert];
//        
//        
//        UIAlertAction* yesButton = [UIAlertAction
//                                    actionWithTitle:@"OK"
//                                    style:UIAlertActionStyleDefault
//                                    handler:^(UIAlertAction * action) {
//                                        //Handle your yes please button action here
//                                        
//                                    }];
//        
//        [alert addAction:yesButton];
//        
//        [self presentViewController:alert animated:YES completion:nil];
//        
//    }
//    
//  
    
  if (self.usernameTxtField.text.length==0)
      
  {
      UIAlertController * alert = [UIAlertController
                                   alertControllerWithTitle:@"Alert"
                                   message:@"Please Fill Username"
                                   preferredStyle:UIAlertControllerStyleAlert];
      
      
      UIAlertAction* yesButton = [UIAlertAction
                                  actionWithTitle:@"OK"
                                  style:UIAlertActionStyleDefault
                                  handler:^(UIAlertAction * action) {
                                      //Handle your yes please button action here
                                      
                                  }];
      
      [alert addAction:yesButton];
      
      [self presentViewController:alert animated:YES completion:nil];
  }
   if (self.passwordTxtField.text.length==0)
      
  {
      UIAlertController * alert = [UIAlertController
                                   alertControllerWithTitle:@"Alert"
                                   message:@"Please Fill Password"
                                   preferredStyle:UIAlertControllerStyleAlert];
      
      
      UIAlertAction* yesButton = [UIAlertAction
                                  actionWithTitle:@"OK"
                                  style:UIAlertActionStyleDefault
                                  handler:^(UIAlertAction * action) {
                                      //Handle your yes please button action here
                                      
                                  }];
      
      [alert addAction:yesButton];
      
      [self presentViewController:alert animated:YES completion:nil];
  }

    else
   {
       
       GoSchool*go=[self.storyboard instantiateViewControllerWithIdentifier:@"School"];
       
       [self presentViewController:go animated:YES completion:^{
           
       }];

   }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
