//
//  GoSchool.h
//  SchoolApp
//
//  Created by Admin on 04/08/2017.
//  Copyright © 2017 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GoSchool : UIViewController
@property (weak, nonatomic) IBOutlet UIScrollView *goScrollView;
@property (weak, nonatomic) IBOutlet UIButton *phoneBttn;
@property (weak, nonatomic) IBOutlet UIButton *dateBirthBttn;
@property (weak, nonatomic) IBOutlet UIButton *academicReportsBttn;
@property (weak, nonatomic) IBOutlet UIButton *logoutBttn;

@property (weak, nonatomic) IBOutlet UIButton *dateJoiningBttn;
@property (weak, nonatomic) IBOutlet UIButton *trackBusBttn;
@property (weak, nonatomic) IBOutlet UIButton *subjectsBttn;
@property (weak, nonatomic) IBOutlet UIButton *studentTrackBttn;
@property (weak, nonatomic) IBOutlet UIButton *attendanceBttn;
@property (weak, nonatomic) IBOutlet UIButton *schedularBttn;
@property (weak, nonatomic) IBOutlet UIButton *notificationBttn;
@property (weak, nonatomic) IBOutlet UIView *profileView;

@end
