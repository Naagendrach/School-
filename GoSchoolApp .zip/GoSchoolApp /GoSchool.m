//
//  GoSchool.m
//  SchoolApp
//
//  Created by Admin on 04/08/2017.
//  Copyright © 2017 Admin. All rights reserved.
//

#import "GoSchool.h"
#import "ViewController.h"
#import "TrackMyBus.h"
#import "Subjects.h"
#import "AcademicReports.h"
#import "StudentTrack.h"
#import "Attendance.h"
#import "Scheduler.h"
#import "Notifications.h"
#import <QuartzCore/QuartzCore.h>


@interface GoSchool ()

@end

@implementation GoSchool

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"1.jpg"]];
//    
//    UIImage *navBackgroundImage = [UIImage imageNamed:@"nav.png"];
//    [[UINavigationBar appearance] setBackgroundImage:navBackgroundImage forBarMetrics:UIBarMetricsDefault];
//    
//    [[UINavigationBar appearance] setTitleTextAttributes: [NSDictionary dictionaryWithObjectsAndKeys:
//                                                           [UIColor colorWithRed:245.0/255.0 green:245.0/255.0 blue:245.0/255.0 alpha:1.0], UITextAttributeTextColor,
//                                                           [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.8],UITextAttributeTextShadowColor,
//                                                           [NSValue valueWithUIOffset:UIOffsetMake(0, 1)],
//                                                           UITextAttributeTextShadowOffset,
//                                                           [UIFont fontWithName:@"HelveticaNeue-CondensedBlack" size:21.0], UITextAttributeFont, nil]];
    self.logoutBttn.layer.cornerRadius = 10; // this value vary as per your desire
    self.logoutBttn.clipsToBounds = YES;
    
    self.phoneBttn.layer.cornerRadius = 10; // this value vary as per your desire
    self.phoneBttn.clipsToBounds = YES;
    
    self.dateBirthBttn.layer.cornerRadius = 10; // this value vary as per your desire
    self.dateBirthBttn.clipsToBounds = YES;
    
    self.dateJoiningBttn.layer.cornerRadius = 10; // this value vary as per your desire
    self.dateJoiningBttn.clipsToBounds = YES;
    
  
    self.trackBusBttn.layer.cornerRadius = 10; // this value vary as per your desire
    self.trackBusBttn.clipsToBounds = YES;
    
    self.subjectsBttn.layer.cornerRadius = 10; // this value vary as per your desire
    self.subjectsBttn.clipsToBounds = YES;
    
    
    self.academicReportsBttn.layer.cornerRadius = 10; // this value vary as per your desire
    self.academicReportsBttn.clipsToBounds = YES;
    
    self.studentTrackBttn.layer.cornerRadius = 10; // this value vary as per your desire
    self.studentTrackBttn.clipsToBounds = YES;
    
    self.schedularBttn.layer.cornerRadius = 10; // this value vary as per your desire
    self.schedularBttn.clipsToBounds = YES;
    
    self.attendanceBttn.layer.cornerRadius = 10; // this value vary as per your desire
    self.attendanceBttn.clipsToBounds = YES;
    
    self.notificationBttn.layer.cornerRadius = 10; // this value vary as per your desire
    self.notificationBttn.clipsToBounds = YES;
    
    
    
    self.profileView.layer.cornerRadius =6; // this value vary as per your desire
    self.profileView.clipsToBounds = YES;

    
    self.goScrollView.contentSize=CGSizeMake(350,1250);
    // Do any additional setup after loading the view.
}
- (IBAction)onLogoutBttnTapped:(id)sender
{
    
    
   

    
}
- (IBAction)logout:(id)sender
{
    UIAlertController * alert = [UIAlertController
                                 alertControllerWithTitle:@"Logout"
                                 message:@"Are You Sure Want to Logout!"
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    //Add Buttons
    
    UIAlertAction* yesButton = [UIAlertAction
                                actionWithTitle:@"Yes"
                                style:UIAlertActionStyleDefault
                                handler:^(UIAlertAction * action) {
                                    //Handle your yes please button action here
                                
                                    
                                    
                                    ViewController*log=[self.storyboard instantiateViewControllerWithIdentifier:@"Login"];
                                    
                                    
                                    [self presentViewController:log animated:YES completion:^{
                                        
                                    }];

                                    
                                    
                                    
                                }];
    
    UIAlertAction* noButton = [UIAlertAction
                               actionWithTitle:@"Cancel"
                               style:UIAlertActionStyleDestructive
                               handler:^(UIAlertAction * action) {
                                   //Handle no, thanks button
                               }];
    
    //Add your buttons to alert controller
    
   
    [alert addAction:yesButton];
    [alert addAction:noButton];
    

    
    [self presentViewController:alert animated:YES completion:nil];
    
    

    
   }
- (IBAction)trackMyBus:(id)sender
{
    
    
    
    TrackMyBus*trk=[self.storyboard instantiateViewControllerWithIdentifier:@"Track"];
    [self presentViewController:trk animated:YES completion:^{
        
    }];
//
//    [self.navigationController pushViewController:trk animated:YES];
   
}
- (IBAction)onSubjectsBttnTapped:(id)sender
{
    
    Subjects*ac=[self.storyboard instantiateViewControllerWithIdentifier:@"Sub1"];
    [self presentViewController:ac animated:YES completion:^{
        
    }];
   
}
- (IBAction)onAcademicsBtnnTapped:(id)sender
{
    
    
    AcademicReports*ac=[self.storyboard instantiateViewControllerWithIdentifier:@"Academic"];
    [self presentViewController:ac animated:YES completion:^{
        
    }];
    
}
- (IBAction)studentTrack:(id)sender
{
    
    
   StudentTrack*St=[self.storyboard instantiateViewControllerWithIdentifier:@"Student"];
    [self presentViewController:St animated:YES completion:^{
        
    }];
    
    
    
}
- (IBAction)attendanceBttn:(id)sender
{
    
    
    Attendance*at=[self.storyboard instantiateViewControllerWithIdentifier:@"Attend"];
    [self presentViewController:at animated:YES completion:^{
        
    }];
  
    
    
    
}
- (IBAction)schedulerBttn:(id)sender
{
    
    
   Scheduler*Scd=[self.storyboard instantiateViewControllerWithIdentifier:@"Scheduler"];
    [self presentViewController:Scd
                       animated:YES completion:^{
        
    }];
    
    
    
}
- (IBAction)notificationBttn:(id)sender
{
    
    
    Notifications*cd=[self.storyboard instantiateViewControllerWithIdentifier:@"Notifications"];
    [self presentViewController:cd
                       animated:YES completion:^{
                           
                       }];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
