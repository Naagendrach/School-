//
//  Notifications.m
//  SchoolApp
//
//  Created by Admin on 04/08/2017.
//  Copyright © 2017 Admin. All rights reserved.
//

#import "Notifications.h"
#import "GoSchool.h"

@interface Notifications ()

@end

@implementation Notifications

- (void)viewDidLoad {
    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"1.jpg"]];
    
    self.view1.layer.cornerRadius = 5;
    self.view1.clipsToBounds = YES;
    
    self.view2.layer.cornerRadius = 5;
    self.view2.clipsToBounds = YES;
    
    self.view3.layer.cornerRadius = 5;
    self.view3.clipsToBounds = YES;
    
    self.view4.layer.cornerRadius = 5;
    self.view4.clipsToBounds = YES;
    
    self.view5.layer.cornerRadius = 5;
    self.view5.clipsToBounds = YES;
    
    self.view6.layer.cornerRadius = 5;
    self.view6.clipsToBounds = YES;
    
    self.view7.layer.cornerRadius = 5;
    self.view7.clipsToBounds = YES;
    
 

    

    
       [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (IBAction)backBarBttn:(id)sender
{
    
    GoSchool*go=[self.storyboard instantiateViewControllerWithIdentifier:@"School"];
    
    //[self.navigationController pushViewController:go animated:YES];
    [self presentViewController:go animated:YES completion:^{
        
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
