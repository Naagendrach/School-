//
//  Subjects.h
//  SchoolApp
//
//  Created by Admin on 04/08/2017.
//  Copyright © 2017 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Subjects : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *teluguSubject;
@property (weak, nonatomic) IBOutlet UIButton *englishSubject;
@property (weak, nonatomic) IBOutlet UIButton *hindiSubject;
@property (weak, nonatomic) IBOutlet UIButton *mathsSubject;
@property (weak, nonatomic) IBOutlet UIButton *socialSubject;
@property (weak, nonatomic) IBOutlet UIButton *scienceSubject;
@property (weak, nonatomic) IBOutlet UIView *profileView;
@property (weak, nonatomic) IBOutlet UIView *examView;
@property (weak, nonatomic) IBOutlet UILabel *subjectLabel;
@property (weak, nonatomic) IBOutlet UILabel *label1;
@property (weak, nonatomic) IBOutlet UILabel *label2;

@property (weak, nonatomic) IBOutlet UILabel *label3;
@property (weak, nonatomic) IBOutlet UILabel *label4;
@property (weak, nonatomic) IBOutlet UILabel *label5;
@property (weak, nonatomic) IBOutlet UILabel *label6;
@end
