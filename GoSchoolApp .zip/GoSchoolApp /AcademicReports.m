//
//  AcademicReports.m
//  SchoolApp
//
//  Created by Admin on 04/08/2017.
//  Copyright © 2017 Admin. All rights reserved.
//

#import "AcademicReports.h"
#import "GoSchool.h"

@interface AcademicReports ()

@end

@implementation AcademicReports

- (void)viewDidLoad {
    
    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"1.jpg"]];
    
    
    [self.examView setHidden:YES];
      [self.examView setHidden:YES];
    
    [self.graphView setHidden:YES];
    [self.graphView setHidden:YES];

    
    self.profileView.layer.cornerRadius =6; // this value vary as per your desire
    self.profileView.clipsToBounds = YES;
    
    
    self.exam1.layer.cornerRadius = 10; // this value vary as per your desire
    self.exam1.clipsToBounds = YES;
    
    
    self.exam2.layer.cornerRadius = 10; // this value vary as per your desire
    self.exam2.clipsToBounds = YES;
    
    
    self.exam3.layer.cornerRadius = 10; // this value vary as per your desire
    self.exam3.clipsToBounds = YES;
    
    
    self.exam4.layer.cornerRadius = 10; // this value vary as per your desire
    self.exam4.clipsToBounds = YES;
    
    
    self.exam5.layer.cornerRadius = 10; // this value vary as per your desire
    self.exam5.clipsToBounds = YES;
    
    
    self.exam6.layer.cornerRadius = 10; // this value vary as per your desire
    self.exam6.clipsToBounds = YES;
    
    self.examView.layer.cornerRadius = 6;
    self.examView.clipsToBounds = YES;
    
    self.graphView.layer.cornerRadius = 6;
    self.graphView.clipsToBounds = YES;
    
    self.onViewGraphBttn.layer.cornerRadius = 8;
    self.onViewGraphBttn.clipsToBounds = YES;

    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (IBAction)backBarBttn:(id)sender
{
    
    GoSchool*go=[self.storyboard instantiateViewControllerWithIdentifier:@"School"];
    
    //[self.navigationController pushViewController:go animated:YES];
    [self presentViewController:go animated:YES completion:^{
        
    }];
    
    

}
- (IBAction)onBackBttnTapped:(id)sender
{
    
    
    
    
  }
- (IBAction)onExam1Tapped:(id)sender
{
  
    
    [self.examView setHidden:NO];
    self.examView.backgroundColor=[UIColor whiteColor];
    
    self.label1.text=@"15";
    self.label2.text=@"15";
    self.label3.text=@"25";
    self.label4.text=@"25";
    self.label5.text=@"25";
    self.label6.text=@"05";
}
- (IBAction)onExam2Tapped:(id)sender
{
    [self.examView setHidden:NO];
    
    self.examView.backgroundColor=[UIColor whiteColor];
    
    self.label1.text=@"25";
    self.label2.text=@"10";
    self.label3.text=@"25";
    self.label4.text=@"25";
    self.label5.text=@"25";
    self.label6.text=@"05";
  
    
}
- (IBAction)viewGraphBttnTapped:(id)sender
{
    
    
    [self.graphView setHidden:NO];
    self.graphView.backgroundColor=[UIColor grayColor];
    
    
    self.graphLabel1.text=@"15";
    self.graphLabel2.text=@"15";
    self.graphLabel3.text=@"25";
    self.graphLabel4.text=@"25";
    self.graphLabel5.text=@"25";
    self.graphLabel6.text=@"05";
 
    
    
}
- (IBAction)onExam3Tapped:(id)sender
{
    
    
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event  {
    NSLog(@"touches began");
    UITouch *touch = [touches anyObject];
    if(touch.view!=self.examView){
        self.examView.hidden = YES;
         self.graphView.hidden = YES;
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
