//
//  AcademicReports.h
//  SchoolApp
//
//  Created by Admin on 04/08/2017.
//  Copyright © 2017 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AcademicReports : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *exam1;
@property (weak, nonatomic) IBOutlet UIButton *exam2;
@property (weak, nonatomic) IBOutlet UIButton *exam3;
@property (weak, nonatomic) IBOutlet UIButton *exam4;
@property (weak, nonatomic) IBOutlet UIButton *exam5;
@property (weak, nonatomic) IBOutlet UIButton *exam6;
@property (weak, nonatomic) IBOutlet UIView *profileView;
@property (weak, nonatomic) IBOutlet UILabel *label1;
@property (weak, nonatomic) IBOutlet UILabel *label2;
@property (weak, nonatomic) IBOutlet UILabel *label3;
@property (weak, nonatomic) IBOutlet UILabel *label4;
@property (weak, nonatomic) IBOutlet UILabel *label5;
@property (weak, nonatomic) IBOutlet UILabel *label6;
@property (weak, nonatomic) IBOutlet UIView *examView;
@property (weak, nonatomic) IBOutlet UIView *graphView;
@property (weak, nonatomic) IBOutlet UILabel *graphLabel1;
@property (weak, nonatomic) IBOutlet UILabel *graphLabel2;
@property (weak, nonatomic) IBOutlet UILabel *graphLabel3;
@property (weak, nonatomic) IBOutlet UILabel *graphLabel4;
@property (weak, nonatomic) IBOutlet UILabel *graphLabel5;
@property (weak, nonatomic) IBOutlet UILabel *graphLabel6;
@property (weak, nonatomic) IBOutlet UIButton *onViewGraphBttn;

@end
