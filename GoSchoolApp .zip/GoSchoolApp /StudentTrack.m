//
//  StudentTrack.m
//  SchoolApp
//
//  Created by Admin on 04/08/2017.
//  Copyright © 2017 Admin. All rights reserved.
//

#import "StudentTrack.h"
#import "GoSchool.h"

@interface StudentTrack ()

@end

@implementation StudentTrack
@synthesize studentMapView;

- (void)viewDidLoad {
    
    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"1.jpg"]];
    
    self.profileView.layer.cornerRadius =6; // this value vary as per your desire
    self.profileView.clipsToBounds = YES;
    
    self.studentMapView.delegate = self;
    //    [btnStandard setBackgroundColor:[UIColor clearColor]];
    //    [btnSatellite setBackgroundColor:[UIColor clearColor]];
    //    [btnHybrid setBackgroundColor:[UIColor greenColor]];
    [studentMapView setMapType:MKMapTypeHybrid];
    [self loadUserLocation];
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (IBAction)backBarBttn:(id)sender
{
    GoSchool*go=[self.storyboard instantiateViewControllerWithIdentifier:@"School"];
    
    //[self.navigationController pushViewController:go animated:YES];
    [self presentViewController:go animated:YES completion:^{
        
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(userLocation.coordinate, 800, 800);
    [self.studentMapView setRegion:[self.studentMapView regionThatFits:region] animated:YES];
    
    MKPointAnnotation *point = [[MKPointAnnotation alloc] init];
    point.coordinate = userLocation.coordinate;
    //point.title = @"Where am I?";
    point.subtitle = @"I'm here!!!";
    
    [self.studentMapView addAnnotation:point];
}


- (void) loadUserLocation
{
    objLocationManager = [[CLLocationManager alloc] init];
    objLocationManager.delegate = self;
    objLocationManager.distanceFilter = kCLDistanceFilterNone;
    objLocationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters;
    if ([objLocationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
        [objLocationManager requestWhenInUseAuthorization];
    }
    [objLocationManager startUpdatingLocation];
}

- (void)locationManager:(CLLocationManager *)manager
     didUpdateLocations:(NSArray *)locations __OSX_AVAILABLE_STARTING(__MAC_NA,__IPHONE_6_0)
{
    CLLocation *newLocation = [locations objectAtIndex:0];
    latitude_UserLocation = newLocation.coordinate.latitude;
    longitude_UserLocation = newLocation.coordinate.longitude;
    [objLocationManager stopUpdatingLocation];
    [self loadMapView];
}

- (void)locationManager:(CLLocationManager *)manager
       didFailWithError:(NSError *)error
{
    [objLocationManager stopUpdatingLocation];
}

- (void) loadMapView
{
    CLLocationCoordinate2D objCoor2D = {.latitude =  latitude_UserLocation, .longitude =  longitude_UserLocation};
    MKCoordinateSpan objCoorSpan = {.latitudeDelta =  0.2, .longitudeDelta =  0.2};
    MKCoordinateRegion objMapRegion = {objCoor2D, objCoorSpan};
    [studentMapView setRegion:objMapRegion];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
