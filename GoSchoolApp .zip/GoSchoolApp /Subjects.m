//
//  Subjects.m
//  SchoolApp
//
//  Created by Admin on 04/08/2017.
//  Copyright © 2017 Admin. All rights reserved.
//

#import "Subjects.h"
#import "GoSchool.h"

@interface Subjects ()

@end

@implementation Subjects

- (void)viewDidLoad {
    
    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"1.jpg"]];
    
    [self.examView setHidden:YES];
    
    self.profileView.layer.cornerRadius =6; // this value vary as per your desire
    self.profileView.clipsToBounds = YES;
    
    self.teluguSubject.layer.cornerRadius = 10; // this value vary as per your desire
    self.teluguSubject.clipsToBounds = YES;
    

    self.hindiSubject.layer.cornerRadius = 10; // this value vary as per your desire
    self.hindiSubject.clipsToBounds = YES;
    

    self.englishSubject.layer.cornerRadius = 10; // this value vary as per your desire
    self.englishSubject.clipsToBounds = YES;
    

    self.mathsSubject.layer.cornerRadius = 10; // this value vary as per your desire
    self.mathsSubject.clipsToBounds = YES;
    

    self.socialSubject.layer.cornerRadius = 10; // this value vary as per your desire
    self.socialSubject.clipsToBounds = YES;
    

    self.scienceSubject.layer.cornerRadius = 10; // this value vary as per your desire
    self.scienceSubject.clipsToBounds = YES;
    
    
    self.examView.layer.cornerRadius = 6;
    self.examView.clipsToBounds = YES;
    


       [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (IBAction)onBackBttnTapped:(id)sender
{
    
    
    
    
    
   
    
    
}
- (IBAction)backBarBttn:(id)sender
{
    
    
    GoSchool*go=[self.storyboard instantiateViewControllerWithIdentifier:@"School"];
    
    //[self.navigationController pushViewController:go animated:YES];
    [self presentViewController:go animated:YES completion:^{
        
    }];
    
    
}
- (IBAction)tappedOnTeluguSub:(id)sender
{
    
    [self.examView setHidden:NO];
    self.examView.backgroundColor=[UIColor whiteColor];
    self.subjectLabel.text=@"Telugu Subject";
    self.label1.text=@"25";
    self.label2.text=@"35";
    self.label3.text=@"45";
    self.label4.text=@"55";
    self.label5.text=@"65";
    self.label6.text=@"75";
    
}
- (IBAction)tappedOnEngSub:(id)sender
{
    
    
    [self.examView setHidden:NO];
    self.examView.backgroundColor=[UIColor whiteColor];
    self.subjectLabel.text=@"English Subject";
    self.label1.text=@"15";
    self.label2.text=@"35";
    self.label3.text=@"25";
    self.label4.text=@"55";
    self.label5.text=@"65";
    self.label6.text=@"95";
}
- (IBAction)tappedOnHinSub:(id)sender
{
    
    
    [self.examView setHidden:NO];
    self.examView.backgroundColor=[UIColor whiteColor];
    self.subjectLabel.text=@"Hindi Subject";
    self.label1.text=@"15";
    self.label2.text=@"35";
    self.label3.text=@"35";
    self.label4.text=@"55";
    self.label5.text=@"65";
    self.label6.text=@"85";
}
- (IBAction)tappedOnMathSub:(id)sender {
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event  {
    NSLog(@"touches began");
    UITouch *touch = [touches anyObject];
    if(touch.view!=self.examView){
        self.examView.hidden = YES;
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
