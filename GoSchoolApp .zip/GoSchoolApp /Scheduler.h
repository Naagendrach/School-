//
//  Scheduler.h
//  SchoolApp
//
//  Created by Admin on 04/08/2017.
//  Copyright © 2017 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Scheduler : UIViewController
@property (weak, nonatomic) IBOutlet UIView *profileView;

@property (weak, nonatomic) IBOutlet UIButton *dropDownView;
@property (weak, nonatomic) IBOutlet UIButton *View1;
@property (weak, nonatomic) IBOutlet UIButton *history;

@property (weak, nonatomic) IBOutlet UIButton *view2;
@property (weak, nonatomic) IBOutlet UIButton *view3;
@end
